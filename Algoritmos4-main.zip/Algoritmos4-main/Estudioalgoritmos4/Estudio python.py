a=7
b=9
c=a+b
print(c)