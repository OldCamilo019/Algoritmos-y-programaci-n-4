print("hola mundo")
a= 1
if a==1:
    print("la variable es igual a 1")

print("aqui termina el condicional")
while a<10:
    print("sigo en ciclo")
    a=a+1
print("aqui termina el condicional")
for i in range (0,10):
    print("sigo en ciclo")
    print(i)
print("aqui termina el condicional")  
  
            